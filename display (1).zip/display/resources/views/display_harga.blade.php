<html>

<head>
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://bootswatch.com/5/flatly/bootstrap.min.css">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <style>
        table,thead,tr,th {
            text-align: center;
            font-size: 40px;
            vertical-align: middle;
            border:1px solid black;
        }
        td{
            font-size: 40px;
        }
        .roll {
            display: none
        }
        .table-info{
            border:1px solid black
        }
        table.table-bordered.table-responsive{
            font-family: Comic Sans MS, Comic Sans, cursive;
            width:100%;
            height:100%;
            margin:0;
        }
    </style>
</head>

<body>
    <table class="table table-bordered table-responsive" id="TableBarang">
        <thead>
            <tr>
                <th>No</th>
                <th>Keterangan</th>
                <th>Harga</th>
                <th >Satuan</th>
            </tr>
        </thead>
        <tbody id="TableBody" class="roll">
            {{-- @foreach($DataTelur as $key=>$Barang)
                <tr class="table-info">
                    <td >{{++$key}}</td>
                    <td >{{$Barang->keterangan}}</td>
                    <td style="text-align: right;">{{number_format($Barang->harga_ecer, 2, ',', '.')}}</td>
                    <td >{{$Barang->satuan}}</td>
                </tr>
            @endforeach --}}
        </tbody>
        <tbody id="TableTriplek" class="roll">
            {{-- @foreach($DataTriplek as $key=>$Triplek)
                <tr class="table-info">
                    <td>{{++$key}}</td>
                    <td>{{$Triplek->keterangan}}</td>
                    <td style="text-align: right;">{{number_format($Triplek->harga_ecer, 2, ',', '.')}}</td>
                    <td>{{$Triplek->satuan}}</td>
                </tr>
            @endforeach --}}
        </tbody>
    </table>
    <script>
        var elem = document.documentElement;
        $(document).ready(function() {
            $(document).keypress(function() {
                if (event.keyCode == 13) {
                    if (elem.requestFullscreen) {
                        elem.requestFullscreen();
                    } else if (elem.webkitRequestFullscreen) {
                        /* Safari */
                        elem.webkitRequestFullscreen();
                    } else if (elem.msRequestFullscreen) {
                        /* IE11 */
                        elem.msRequestFullscreen();
                    }
                }

            });
        });

        $(document).ready(function() {
            var current = 0;
            $('#TableBody').show();
            setInterval(function() {
            var divs = $(".roll").hide();
            divs.eq(current).fadeIn("fast");
            if (current < divs.length - 1)
                current++;
            else
                current = 0;
            }, 60000);
            setTimeout(function(){
                window.location.reload();
            }, 180000);

        });

        $.ajax({
            url: "{{ route('DataHargaBarang') }}"
        }).done(function(data){
            $('#TableTriplek').append(data['DataTriplek']);
            $('#TableBody').append(data['DataTelur']);
            $.each(data['DataTelur'], function(index, value){
                var no = index +1;
                var harga = value['harga_ecer'].toLocaleString("en");
                $('#TableBody').append('<tr class="table-info"><td>'+no+'</td><td>'+value.keterangan+'</td><td style="text-align: right;">'+harga+'</td><td>'+value.satuan+'</td></tr>');
            });
            $.each(data['DataTriplek'], function(index, value){
                var no = index +1;
                var harga = value['harga_ecer'].toLocaleString("en");
                $('#TableTriplek').append('<tr class="table-info"><td>'+no+'</td><td>'+value.keterangan+'</td><td style="text-align: right;">'+harga+'</td><td>'+value.satuan+'</td></tr>');
            });
        });
    </script>
</body>

</html>
