<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('master_harga', 'MasterHargaController@index')->name('IndexMasterHarga');
Route::post('master_harga', 'MasterHargaController@insert')->name('InsertMasterHarga');
Route::get('ListBarang', 'MasterHargaController@ListBarang')->name('ListBarang');
Route::get('master_harga/detail/{id}', 'MasterHargaController@detail')->name('DetailMasterHarga');
Route::post('master_harga/update', 'MasterHargaController@update')->name('UpdateMasterHarga');
Route::get('master_harga/delete/{id}', 'MasterHargaController@destroy')->name('DeleteMasterHarga');


Route::get('/display', 'DisplayHargaController@index')->name('HargaBarangIndex');
Route::get('/display-harga', 'DisplayHargaController@DataHargaBarang')->name('DataHargaBarang');
