<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use DataTables;

class MasterHargaController extends Controller
{
    public function index(){
        return view("master_harga");
    }

    public function ListBarang(){
        $DataBarang = DB::table('harga_barang')->get();
        return DataTables::of($DataBarang)
        ->addColumn('action', function ($DataBarang) {
            return '<button type="button" id="'.$DataBarang->id.'" onclick="ButtonEdit(this.id)" class="btn btn-success btn-xs ">Edit</button>
                    <button type="button" id="'.$DataBarang->id.'" onclick="ButtonDelete(this.id)" class="btn btn-danger btn-xs ">Hapus</button>';
        })->make(true);
    }

    public function insert(Request $request){
        $validator = Validator::make($request->all(),[
                'keterangan' => 'required',
                'harga_ecer' => 'required',
                'satuan' => 'required',
                'kategori' => 'required'
            ],
            [
                'keterangan.required' => 'Masukkan Keterangan Nama Barang !',
                'harga_ecer.required' => 'Masukkan Keterangan Harga Ecer Barang !',
                'satuan.required' => 'Masukkan Keterangan Satuan Barang !',
                'kategori.required' => 'Masukkan Keterangan Kategori Barang !'
            ]
        );
        if($validator->fails()) {

            return response()->json([
                'success' => false,
                'message' => 'Silahkan Isi Kolom Yang Kosong',
                'data'    => $validator->errors()
            ],401);

        } else {

            $post = DB::table('harga_barang')->insert([
                'keterangan' => $request->keterangan,
                'harga_ecer' => $request->harga_ecer,
                'satuan' => $request->satuan,
                'kategori' => $request->kategori
            ]);

            if ($post) {
                return response()->json([
                    'success' => true,
                    'message' => 'Post Berhasil Disimpan!',
                ], 200);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Post Gagal Disimpan!',
                ], 401);
            }
        }
    }

    public function detail(Request $request){
        $id = $request->id;
        $DataBarang = DB::table('harga_barang')->where("id",$id)->get();
        return response()->json($DataBarang);
    }

    public function update(Request $request){
        if($request->ajax()){
            $id = $request->id;
            $keterangan = $request->keterangan;
            $harga_ecer = $request->harga_ecer;
            $satuan = $request->satuan;
            $kategori = $request->kategori;

           $post = DB::table('harga_barang')->where("id",$id)->update([
                'keterangan' => $keterangan,
                'harga_ecer' => $harga_ecer,
                'satuan' => $satuan,
                'kategori'=>$kategori
            ]);
            if ($post) {
                return response()->json([
                    'success' => true,
                    'message' => 'Post Berhasil Disimpan!',
                ], 200);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Post Gagal Disimpan!',
                ], 401);
            }
        }

    }

    public function destroy($id){
        $post = DB::table('harga_barang')->where('id',$id)->delete();
        return response()->json($post);
    }
}
