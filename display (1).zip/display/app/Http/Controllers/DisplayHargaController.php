<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DisplayHargaController extends Controller
{
    public function index(){
        return view('/display_harga');
    }

    public function DataHargaBarang(){
        $DataTelur = DB::table('harga_barang')->where("kategori","telur")->get();
        $DataTriplek = DB::table('harga_barang')->where("kategori","triplek")->get();
        $DataBarang = ['DataTelur' => $DataTelur,'DataTriplek'=> $DataTriplek];
        return  response()->json($DataBarang);

        //return view('/display_harga',['DataTelur' => $DataTelur,'DataTriplek'=> $DataTriplek]);
    }
}
