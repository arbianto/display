<?php $__env->startSection('title', 'Master Harga Barang'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Master Harga Barang</h1>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <body>
        <div class="col-md-12">
            <button type="button" style="margin:10px 0px" class=" btn btn-primary " onclick="ButtonAdd()">Tambah
                Baru</button>
        </div>
        
        <?php echo csrf_field(); ?>
        <div class="modal" id="ModalAdd">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Tambah Barang</h5>
                        <span aria-hidden="true"></span>
                        </button>
                    </div>
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <form id="FormAdd">
                            <div class="form-group">
                                <label for="keterangan">Keterangan</label>
                                <input type="hidden" name="id" id="id" required="required"></input>
                                <input type="text" name="keterangan" id="keterangan" required="required"
                                    class="form-control" placeholder="Masukkan Keterangan"></input>
                            </div>
                            <div class="form-group">
                                <label for="harga_ecer">Harga</label>
                                <input type="number" name="harga_ecer" id="harga_ecer" required="required"
                                    class="form-control" placeholder="Masukkan Harga"></input>
                            </div>
                            <div class="form-group">
                                <label for="satuan">Satuan Barang</label>
                                <input type="text" name="satuan" id="satuan" required="required" class="form-control"
                                    placeholder="Masukkan Satuan"></input>
                            </div>
                            <div class="form-group" style="margin:0;">
                                <label for="Kategori"> Kategori</label>
                            </div>
                            <div class="form-group">
                                <input type="radio" class="form-check-input" name="optionsRadios" id="KategoriTelur" value="Telur" checked="">Telur</input>
                                  <input type="radio" style = "margin-left:15px;" class="form-check-input" name="optionsRadios" id="KategoriTriplek" value="Triplek">Triplek</input>
                            </div>
                            
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" onclick="ButtonInsert()" data-dismiss="modal">Save
                            changes</button>
                        <button type="button" class="btn btn-secondary" onclick="ButtonClose()">Close</button>
                    </div>
                    </form>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <table class="table table-bordered" style="width: 100%" id="TableHargaBarang">
                    <thead>
                        <tr>
                            <th>Keterangan</th>
                            <th> Harga</th>
                            <th> Satuan </th>
                            <th> Kategori </th>
                            <th> X </th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </body>
    
    <div class="modal" id="ModalEdit">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Data Barang</h5>
                    <span aria-hidden="true"></span>
                    </button>
                </div>
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <form id="FormEdit">
                        <div class="form-group">
                            <label for="EditKeterangan">Nama</label>
                            <input type="hidden" name="id" id="EditId" required="required"></input>
                            <input type="text" name="EditKeterangan" id="EditKeterangan" required="required"
                                class="form-control" placeholder="Masukkan Keterangan"></input>
                        </div>
                        <div class="form-group">
                            <label for="EditHargaEcer">Harga</label>
                            <input type="number" name="EditHargaEcer" id="EditHargaEcer" required="required"
                                class="form-control" placeholder="Masukkan Harga"></input>
                        </div>
                        <div class="form-group">
                            <label for="EditSatuan">Satuan</label>
                            <input type="text" name="EditSatuan" id="EditSatuan" required="required" class="form-control"
                                placeholder="Masukkan Satuan"></input>
                        </div>
                        <div class="form-group" style="margin:0;">
                            <label for="Kategori"> Kategori</label>
                        </div>
                        <div class="form-group">
                            <input type="radio" class="form-check-input" name="optionsRadios" id="EditKategoriTelur" value="Telur" checked="">Telur</input>
                              <input type="radio" style = "margin-left:15px;" class="form-check-input" name="optionsRadios" id="EditKategoriTriplek" value="Triplek">Triplek</input>
                        </div>
                        
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" onclick="ButtonUpdate()">Save changes</button>
                    <button type="button" class="btn btn-secondary" onclick="ButtonClose()">Close</button>
                </div>
                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        function Clear() {
            $('#keterangan').val('');
            $('#harga_ecer').val('');
            $('#satuan').val('');

            $('#EditKeterangan').val('');
            $('#EditHargaEcer').val('');
            $('#EditSatuan').val('');

            $('#ModalAdd').modal('hide')
            $('#ModalEdit').modal('hide')
        }
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        function ButtonAdd() {
            $('#ModalAdd').modal('show');
        }

        function ButtonInsert() {
            var keterangan = $('#keterangan').val();
            var harga_ecer = $('#harga_ecer').val();
            var satuan = $('#satuan').val();
            var KategoriTelur = $('#KategoriTelur:checked').val();
            var KategoriTriplek = $('#KategoriTriplek:checked').val();
            var kategori = (KategoriTelur) ? KategoriTelur : KategoriTriplek;
            var _token   = $('meta[name="csrf-token"]').attr('content');

            $(this).prop('disabled', true);
            $.ajax({
                url: "<?php echo e(route('InsertMasterHarga')); ?>",
                type: "post",
                dataType: "JSON",
                _token: _token,
                data: {
                    'keterangan': keterangan,
                    'harga_ecer': harga_ecer,
                    'satuan': satuan,
                    'kategori': kategori
                },

                success: function(data) {
                    if (data) {
                        Clear()
                        Swal.fire({
                            position: 'top-end',
                            type: 'success',
                            title: 'Data Berhasil Disimpan',
                            showConfirmButton: false,
                            timer: 1000
                        })
                        $('#TableHargaBarang').DataTable().ajax.reload();
                    }

                },
                error: function(jqXHR, status, error) {
                    var errorObj = jqXHR.responseJSON;
                    alert(errorObj.message);
                }

            });
        }

        function ButtonUpdate() {
            var id = $('#EditId').val();
            var keterangan = $('#EditKeterangan').val();
            var harga_ecer = $('#EditHargaEcer').val();
            var satuan = $('#EditSatuan').val();
            var EditKategoriTelur = $('#EditKategoriTelur:checked').val();
            var EditKategoriTriplek = $('#EditKategoriTriplek:checked').val();
            var kategori = (EditKategoriTelur) ? EditKategoriTelur : EditKategoriTriplek;
            $(this).prop('disabled', true);
            $.ajax({
                url: "<?php echo e(route('UpdateMasterHarga')); ?>",
                type: "post",
                dataType: "JSON",
                data: {
                    'id': id,
                    'keterangan': keterangan,
                    'harga_ecer': harga_ecer,
                    'satuan': satuan,
                    'kategori': kategori
                },

                success: function(data) {
                    if (data) {
                        Clear()
                        Swal.fire({
                            position: 'top-end',
                            type: 'success',
                            title: 'Data Berhasil Disimpan',
                            showConfirmButton: false,
                            timer: 1000
                        })
                        $('#TableHargaBarang').DataTable().ajax.reload();
                    }

                },
                error: function (data) {
                    alert('Error:', data);
                }

            });
        }

        function ButtonDelete(id) {
            var url = '<?php echo e(route("DeleteMasterHarga", "id")); ?>';
            url = url.replace('id', id);
            Swal.fire({
                title: 'Apakah Anda Yakin?',
                text: "Ingin Menghapus Data Ini!",
                type: 'warning',

                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Delete!'
            }).then((result) => {
                if (result.value) {
                    $.ajax({
                        url:url,
                        type: "get",
                        dataType: "JSON",
                        success: function(data) {
                            if (data) {
                                $('#TableHargaBarang').DataTable().ajax.reload();
                                Swal.fire(
                                    'Deleted!',
                                    'Your file has been deleted.',
                                    'success'
                                )
                            }

                        },
                        error: function (data) {
                            alert('Error:', data);
                        }

                    });
                }
            })
        }

        function ButtonEdit(id) {
            var url = '<?php echo e(route("DetailMasterHarga", "id")); ?>';
            url = url.replace('id', id);
            $.ajax({
                url: url,
                type: "GET",
                dataType: "JSON",
                success: function(data) {
                    $('#EditId').val(data[0].id);
                    $('#EditKeterangan').val(data[0].keterangan);
                    $('#EditHargaEcer').val(data[0].harga_ecer);
                    $('#EditSatuan').val(data[0].satuan);
                    // $('#EditKategori').val(data[0].kategori);
                    $('input[name="optionsRadios"][value="' + data[0].kategori + '"]').prop('checked', true);
                    $('#ModalEdit').modal('show');
                },
                error: function (data) {
                            alert('Error:', data);
                }
            });
        }

        function ButtonClose() {
            Clear()
        }

        $(document).ready(function() {
            $('#TableHargaBarang').DataTable({
                processing: true,
                serverSide: true,
                dataType: "JSON",
                ajax: "<?php echo e(route('ListBarang')); ?>",
                columns: [{
                        data: 'keterangan',
                        name: 'keterangan'
                    },
                    {
                        data: 'harga_ecer',
                        render: $.fn.dataTable.render.number('.', '.', 0, 'Rp.'),
                        name: 'harga_ecer'
                    },
                    {
                        data: 'satuan',
                        name: 'satuan'
                    },
                    {
                        data: 'kategori',
                        name: 'kategori'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    }
                ]
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>